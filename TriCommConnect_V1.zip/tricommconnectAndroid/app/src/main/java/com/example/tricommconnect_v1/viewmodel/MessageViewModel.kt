package com.example.tricommconnect_v1.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.tricommconnect_v1.data.model.Message
import com.example.tricommconnect_v1.data.local.entity.MessageEntity
import com.example.tricommconnect_v1.data.local.mapper.toEntity
import com.example.tricommconnect_v1.data.local.mapper.toModel
import com.example.tricommconnect_v1.data.repository.MessageRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed class MessageState {
    object Loading : MessageState()
    data class Success(val messages: List<Message>) : MessageState()
    data class Error(val error: String) : MessageState()
    object Idle : MessageState()
    data class Sent(val message: Message) : MessageState()
}

class MessageViewModel(
    private val messageRepository: MessageRepository
) : ViewModel() {

    private val _state = MutableStateFlow<MessageState>(MessageState.Idle)
    val state: StateFlow<MessageState> = _state

    fun observeMessages(chatId: String) {
        viewModelScope.launch {
            _state.value = MessageState.Loading

            // Flow from Room
            messageRepository.getLocalMessagesFlow(chatId)
                .map { list -> list.map { it.toModel() } }
                .onEach { _state.value = MessageState.Success(it) }
                .launchIn(viewModelScope)

            // Fetch from API, update Room
            try {
                val remoteMessages = messageRepository.fetchRemoteMessages(chatId)
                messageRepository.saveMessagesToLocal(remoteMessages)
            } catch (e: Exception) {
                _state.value = MessageState.Error("Sync failed: ${e.message}")
            }
        }
    }

    fun sendMessage(chatId: String, senderId: String, body: String) {
        viewModelScope.launch {
            try {
                val sentMsg = messageRepository.sendMessage(chatId, senderId, body)
                sentMsg?.let {
                    messageRepository.saveMessagesToLocal(listOf(it))
                    _state.value = MessageState.Sent(it)
                    Log.d("MessageViewModel", "Message sent successfully: $it")
                } ?: run {
                    _state.value = MessageState.Error("Message send returned null")
                }
            } catch (e: Exception) {
                _state.value = MessageState.Error("Send failed: ${e.message}")
            }
        }
    }

    fun resetState() {
        _state.value = MessageState.Idle
    }
}
