package com.example.tricommconnect_v1.data.model

data class ChatListResponse(
    val chatNames: List<String>
)
